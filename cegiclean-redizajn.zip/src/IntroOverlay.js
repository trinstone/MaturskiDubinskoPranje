import { useEffect, useState } from 'react';
import './cssPojedinacni/IntroOverlay.css';

const KLJUC_SESIJE = 'cegiCleanIntroPrikazan';

const IntroOverlay = () => {
    const [prikazi] = useState(() => {
        if (typeof window === 'undefined') return false;
        const vecPrikazano = sessionStorage.getItem(KLJUC_SESIJE);
        const smanjeniPokreti = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        if (vecPrikazano || smanjeniPokreti) return false;
        sessionStorage.setItem(KLJUC_SESIJE, '1');
        return true;
    });
    const [animiraj, setAnimiraj] = useState(false);
    const [ukloni, setUkloni] = useState(false);

    useEffect(() => {
        if (!prikazi) return;

        const pokretac = setTimeout(() => setAnimiraj(true), 400);
        const zavrsetak = setTimeout(() => setUkloni(true), 4200);

        return () => {
            clearTimeout(pokretac);
            clearTimeout(zavrsetak);
        };
    }, [prikazi]);

    const preskoci = () => setUkloni(true);

    if (!prikazi || ukloni) return null;

    return (
        <div className={`intro-overlay ${animiraj ? 'intro-animiraj' : ''}`}>
            <div className="intro-plava" />
            <div className="intro-masina">
                <svg viewBox="0 0 160 100" className="intro-masina-svg" aria-hidden="true">
                    <rect x="0" y="38" width="78" height="11" rx="5.5" fill="#B8C4D1" />
                    <rect x="66" y="22" width="18" height="42" rx="5" fill="#3A4652" />
                    <rect x="78" y="27" width="16" height="32" rx="3" fill="#F5C518" />
                    <polygon points="92,20 148,10 156,50 92,64" fill="#E4EAF0" stroke="#9AA5B1" strokeWidth="1.6" />
                    <polygon points="92,20 148,10 144,20 92,30" fill="#F4F7FA" opacity="0.8" />
                </svg>
            </div>
            <button type="button" className="intro-preskoci" onClick={preskoci}>
                Preskoči
            </button>
        </div>
    );
};

export default IntroOverlay;
